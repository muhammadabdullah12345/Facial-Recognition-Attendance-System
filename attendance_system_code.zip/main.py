# Smart Attendance System using BlazeFace + MobileFaceNet

import os
import cv2
import mediapipe as mp
import torch
from torchvision import transforms
from sklearn.metrics.pairwise import cosine_similarity
import datetime

# ---------------- Dataset Loader ----------------
DATASET_PATH = "dataset/"

def load_dataset(path=DATASET_PATH):
    images = []
    labels = []
    for label in os.listdir(path):
        folder = os.path.join(path, label)
        if not os.path.isdir(folder):
            continue
        for file in os.listdir(folder):
            img_path = os.path.join(folder, file)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            img = cv2.resize(img, (112, 112))
            images.append(img)
            labels.append(label)
    return images, labels

# ---------------- BlazeFace Detector ----------------
mp_face = mp.solutions.face_detection
face_detection = mp_face.FaceDetection(model_selection=0, min_detection_confidence=0.5)

def detect_faces(image):
    results = face_detection.process(image)
    if not results.detections:
        return None
    detections = []
    h, w, _ = image.shape
    for det in results.detections:
        box = det.location_data.relative_bounding_box
        x, y, w_box, h_box = box.xmin, box.ymin, box.width, box.height
        x1, y1 = int(x*w), int(y*h)
        x2, y2 = int((x+w_box)*w), int((y+h_box)*h)
        detections.append((x1, y1, x2, y2))
    return detections

# ---------------- MobileFaceNet Embeddings ----------------
# Dummy model placeholder; replace with actual MobileFaceNet class file
class MobileFaceNet(torch.nn.Module):
    def __init__(self, embedding_size=128):
        super().__init__()
        self.flatten = torch.nn.Flatten()
        self.fc = torch.nn.Linear(112*112, embedding_size)

    def forward(self, x):
        return self.fc(self.flatten(x))

model = MobileFaceNet(embedding_size=128)
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Resize((112, 112)),
    transforms.Normalize([0.5], [0.5])
])

def get_embedding(img):
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    tensor = transform(img).unsqueeze(0)
    with torch.no_grad():
        emb = model(tensor).numpy()
    return emb

# ---------------- Build Database ----------------
def build_embedding_database(images, labels):
    db = {}
    for img, label in zip(images, labels):
        emb = get_embedding(img)
        if label not in db:
            db[label] = []
        db[label].append(emb)
    return db

# ---------------- Recognize Face ----------------
def recognize_face(face_img, database, threshold=0.55):
    emb = get_embedding(face_img)
    best_label = "Unknown"
    best_score = 0
    for label in database:
        stored_embs = database[label]
        for db_emb in stored_embs:
            score = cosine_similarity(emb.reshape(1, -1), db_emb.reshape(1, -1))[0][0]
            if score > best_score and score > threshold:
                best_score = score
                best_label = label
    return best_label, best_score

# ---------------- Attendance Logic ----------------
attendance = {}

def mark_attendance(student_name):
    now = datetime.datetime.now()
    attendance[student_name] = now.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Attendance marked for {student_name}")

# ---------------- Main Simulation ----------------
if __name__ == "__main__":
    print("Loading dataset...")
    images, labels = load_dataset()
    database = build_embedding_database(images, labels)
    print("Database ready!")

    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        detections = detect_faces(frame)
        if detections:
            for (x1, y1, x2, y2) in detections:
                face = frame[y1:y2, x1:x2]
                student_name, score = recognize_face(face, database)

                if student_name != "Unknown":
                    mark_attendance(student_name)

                cv2.putText(frame, student_name, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        cv2.imshow("Attendance System Simulation", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
